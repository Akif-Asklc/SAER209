from django.shortcuts import render
from .forms import EcurieForm
from django.http import HttpResponseRedirect
from . import models

# Create your views here.

def add(request):
    if request.method == "POST":
        form = EcurieForm(request)
        return render(request,"paddock/ecurie/add.html",{"form": form})
    else :
        form = EcurieForm() # création d'un formulaire vide
    return render(request,"paddock/ecurie/add.html",{"form" : form})

def treatment(request):
    eform = EcurieForm(request.POST)
    if eform.is_valid():
        ecurie = eform.save()
        return HttpResponseRedirect("/paddock/")
    else:
        return render(request,"paddock/ecurie/add.html",{"form": eform})

def index(request):
    liste = list(models.Ecurie.objects.all())
    return render(request, 'paddock/ecurie/index.html', {'liste' : liste })

def read(request, id):
    ecurie = models.Ecurie.objects.get(pk=id)
    liste = list(models.Pilot.objects.filter(ecurie_id=id))
    return render(request,"paddock/ecurie/read.html",{"ecurie": ecurie, "liste": liste})

def update(request, id):
    ecurie = models.Ecurie.objects.get(pk=id)
    form = EcurieForm(ecurie.dict())
    return render(request,"paddock/ecurie/add.html",{"form": form, "id": id})

def updatetreatment(request, id):
    eform = EcurieForm(request.POST)
    if eform.is_valid():
        ecurie = eform.save(commit=False)
        ecurie.id = id
        ecurie.save()
        return HttpResponseRedirect("/paddock/")
    else:
        return render(request, "paddock/ecurie/add.html", {"form": eform, "id": id})

def delete(request, id):
    ecurie = models.Ecurie.objects.get(pk=id)
    ecurie.delete()
    return HttpResponseRedirect("/paddock/")