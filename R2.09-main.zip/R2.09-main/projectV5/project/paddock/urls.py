from django.urls import path
from . import views, views_pilot
urlpatterns = [

#URLs ecurie

    path('add/', views.add),
    path('treatment/', views.treatment),
    path('', views.index),
    path('read/<int:id>/', views.read),
    path('update/<int:id>/', views.update),
    path('updatetreatment/<int:id>/', views.updatetreatment),
    path('delete/<int:id>/', views.delete),
  
#URLs pilot

    path('add_pilot/<int:id>/', views_pilot.add),
    path('treatment_pilot/<int:id>/', views_pilot.treatment),
    path('pilot/', views_pilot.index),
    path('read_pilot/<int:id>/', views_pilot.read),
    path('update_pilot/<int:id>/', views_pilot.update),
    path('updatetreatment_pilot/<int:id>/', views_pilot.updatetreatment),
    path('delete_pilot/<int:id>/', views_pilot.delete),
]
