from django.forms import ModelForm
from django.utils.translation import gettext_lazy as _
from . import models


class EcurieForm(ModelForm):
    class Meta:
        model = models.Ecurie
        fields = ('nom', 'team_principal', 'annee_creation', 'nbr_titres_constructeurs')
        labels = {
            'nom' : _('Nom'),
            'team_principal' : _('Team principal') ,
            'annee_creation' : _('Année de création'),
            'nbr_titres_constructeurs' : _('Nombre de titres constructeurs')
        }


class PilotForm(ModelForm):
    class Meta:
        model = models.Pilot
        fields = ('nom', 'prenom', 'age','nbr_titres_pilote')
        labels = {
            'nom' : _('Nom'),
            'prenom' : _('Prénom') ,
            'age' : _('Age'),
            'nbr_titres_pilote' : _('Nombre de titres pilote')
        }