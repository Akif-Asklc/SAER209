from django.db import models

# Create your models here.

class Ecurie(models.Model):

    nom = models.CharField(max_length=100)
    team_principal = models.CharField(max_length=100)
    annee_creation = models.IntegerField(blank=True, null=True)
    nbr_titres_constructeurs = models.IntegerField(null=True)

    def __str__(self):
        return f"{self.nom} créée en {self.annee_creation} et dirigée par {self.team_principal}."

    def dict(self):
        return {'nom': self.nom, 'team_principall': self.team_principal, 'annee_creation': self.annee_creation,
                 'nbr_titres_constructeurs': self.nbr_titres_constructeurs}


class Pilot(models.Model):

    nom = models.CharField(max_length=100)
    prenom = models.CharField(max_length=100)
    age = models.IntegerField(null=True)
    nbr_titres_pilote = models.IntegerField(null=True)
    ecurie = models.ForeignKey(Ecurie, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.prenom} {self.nom} agé de {self.age} ans."
    
    def dict(self):
        return {'nom': self.nom, 'prenom': self.prenom, 'age': self.age, 
                'nbr_titres_pilote': self.nbr_titres_pilote, 'ecurie': self.ecurie}
