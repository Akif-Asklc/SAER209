from django.shortcuts import render
from .forms import *
from django.http import HttpResponseRedirect
from . import models

# Create your views here.

def add(request,id):
    if request.method == "POST":
        form = PilotForm(request.POST)
        return render(request,"paddock/pilot/add.html",{"form": form, "id_e": id})
    else :
        form = PilotForm() # création d'un formulaire vide
    return render(request,"paddock/pilot/add.html",{"form" : form, "id_e": id})

def treatment(request, id):
    ecurie = models.Ecurie.objects.get(pk=id)
    pform = PilotForm(request.POST)
    if pform.is_valid():
        pilot = pform.save(commit=False)
        pilot.ecurie = ecurie
        pilot.ecurie_id = id
        pilot.save()
        return HttpResponseRedirect("/paddock/pilot/")
    else:
        return render(request,"paddock/pilot/add.html",{"form": pform})

def index(request):
    liste = list(models.Pilot.objects.all())
    return render(request, 'paddock/pilot/index.html', {'liste' : liste })

def read(request, id):
    pilot = models.Pilot.objects.get(pk=id)
    return render(request,"paddock/pilot/read.html",{"pilot": pilot})

def update(request, id):
    pilot = models.Pilot.objects.get(pk=id)
    form = PilotForm(pilot.dict())
    return render(request,"paddock/pilot/add.html",{"form": form, "id_p": id})

def updatetreatment(request, id):
    pilot = models.Pilot.objects.get(pk=id)
    pform = PilotForm(request.POST, instance=pilot)
    if pform.is_valid():
        pilot = pform.save()
        return HttpResponseRedirect('/paddock/pilot/')
    
def delete(request, id):
    pilot = models.Pilot.objects.get(pk=id)
    pilot.delete()
    return HttpResponseRedirect("/paddock/pilot/")