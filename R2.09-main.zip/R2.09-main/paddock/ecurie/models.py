from django.db import models

# Create your models here.

class Ecurie(models.Model):

    nom = models.CharField(max_length=100)
    team_principal = models.CharField(max_length=100)
    annee_creation = models.IntegerField(blank=True, null=True)
    annee_fin = models.IntegerField(blank=True, null=True)
    nbr_titres_constructeurs = models.IntegerField(blank=False)

    def __str__(self):
        return f"{self.nom} créée en {self.annee_creation} et dirigée par {self.team_principal}."

    def dictionnaire(self):
        return {'Nom': self.nom, 'Team principal': self.team_principal, 'Année de création': self.annee_creation,
                'Annee de fin': self.annee_fin, 'Nombre de titres constructeurs': self.nbr_titres_constructeurs}
