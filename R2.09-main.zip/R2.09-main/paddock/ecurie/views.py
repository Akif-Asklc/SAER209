from django.shortcuts import render
from .forms import EcurieForm
from django.http import HttpResponseRedirect
from . import models

# Create your views here.

def index(request):
    return render(request,"ecurie/index.html")

def add(request):
    if request.method == "POST":
        form = EcurieForm(request)
        if form.is_valid(): # validation du formulaire.
            Ecurie = form.save() # sauvegarde dans la base
            return render(request,"ecurie/read.html",{"Ecurie" : Ecurie})
        else:
            return render(request,"ecurie/add.html",{"form": form})
    else :
        form = EcurieForm() # création d'un formulaire vide
    return render(request,"ecurie/add.html",{"form" : form})

def treatment(request):
    eform = EcurieForm(request.POST)
    if eform.is_valid():
        Ecurie = eform.save()
        return render(request,"ecurie/read.html",{"Ecurie" : Ecurie})
    else:
        return render(request,"ecurie/add.html",{"form": eform})